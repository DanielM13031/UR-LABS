module.exports = {
    timezone: 'America/Bogota',


    isScheduler: true,

    mail: {
        host: 'smtp.example.com',
        port: 587,
        secure: false,
        auth: {
            user: 'danieljosemorales05@gmail,con',
            pass: 'wuti bwyu lokz aamu',
            from: 'danieljosemorales05@gmail.com'
            }
        }
};