const router = require('express').Router();
const { loadCutoffs } = require('../lib/config');
const { runReminderJob, runCutoffJob } = require('../jobs/cutoffService');

// Aplica tu middleware de autenticación de admin aquí si ya lo tienes
// router.use(authMiddlewareAdmin);

router.get('/cutoff', async (_req, res) => {
    res.json(loadCutoffs());
});

router.post('/cutoff/remind/run', async (_req, res) => {
    res.json(await runReminderJob());
});

router.post('/cutoff/apply/run', async (_req, res) => {
    res.json(await runCutoffJob());
});

module.exports = router;
