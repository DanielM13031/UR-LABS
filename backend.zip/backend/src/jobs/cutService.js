const { Reservation, User, Locker } = require('../models');
const { sendMail } = require('../lib/email');
const { loadCutoffs } = require('../lib/config');
const { Op } = require('sequelize');

function daysDiff(now, target) {
    const MS = 24*60*60*1000;
    return Math.ceil((target - now) / MS);
}

async function runReminderJob() {
    const cutoff = loadCutoffs();
    if (!cutoff) return { ok: true, msg: 'No hay cutoff activo' };

    const now = new Date();
    const cutoffDate = new Date(cutoff.cutoff_at);
    const diff = daysDiff(now, cutoffDate);

    if (diff !== Number(cutoff.remind_days_before)) {
        return { ok: true, msg: `No corresponde enviar recordatorio (faltan ${diff} días)` };
    }

    const resvs = await Reservation.findAll({
        where: { status: 'active' },
        include: [
        { model: User, attributes: ['email', 'name'] },
        { model: Locker, attributes: ['code'] }
        ]
    });

    let sent = 0;
    for (const r of resvs) {
        const email = r?.User?.email;
        if (!email) continue;
        const { subject, html, text } = require('../templates/reminder')({
        name: r.User?.name,
        cutoffDate: cutoffDate.toLocaleDateString('es-CO'),
        lockerCode: r.Locker?.code || r.locker_id
        });
        await sendMail({ to: email, subject, html, text });
        sent++;
    }

    return { ok: true, remindersSent: sent };
}

async function runCutoffJob() {
    const cutoff = loadCutoffs();
    if (!cutoff) return { ok: true, msg: 'No hay cutoff activo' };

    const now = new Date();
    const start = new Date(cutoff.cutoff_at);
    const end = new Date(start.getTime() + 24*60*60*1000);
    if (!(now >= start && now < end)) {
        return { ok: true, msg: 'Aún no es la ventana de corte' };
    }

    const actives = await Reservation.findAll({
        where: { status: 'active' },
        include: [
        { model: User, attributes: ['email', 'name'] },
        { model: Locker, attributes: ['id', 'code'] }
        ]
    });

    let expiredCount = 0, mailed = 0;
    for (const r of actives) {
        await r.update({ status: 'expired', expired_at: now });
        if (r.Locker) await r.Locker.update({ is_available: true });

        const email = r?.User?.email;
        if (email) {
        const { subject, html, text } = require('../templates/expired')({
            name: r.User?.name,
            lockerCode: r.Locker?.code || r.locker_id,
            cutoffDate: start.toLocaleDateString('es-CO')
        });
        await sendMail({ to: email, subject, html, text });
        mailed++;
        }
        expiredCount++;
    }

    // Borrado/archivo tras periodo de gracia
    const grace = Number(cutoff.grace_days || 0);
    let hardDeleted = 0;
    if (grace > 0) {
        const limit = new Date(now.getTime() - grace*24*60*60*1000);
        const toDelete = await Reservation.findAll({
        where: { status: 'expired', expired_at: { [Op.lt]: limit } }
        });
        const ids = toDelete.map(r => r.id);
        if (ids.length) {
        await Reservation.destroy({ where: { id: ids } });
        hardDeleted = ids.length;
        }
    }
    return { ok: true, expiredCount, mailed, hardDeleted };
}

module.exports = { runReminderJob, runCutoffJob };
